﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace libraryproject.Models
{
    public class ApplicationDbContext:IdentityDbContext<ApplicationUser,ApplicationRole,string>
    {
        //public ApplicationDbContext(DbcontextOptions<ApplicationDbContext> Options):base(Option)
        //{

        //}

        //public Dbset<Members> members { get; set; }

        //internal void SaveChanges();
        public Dbset<Author> authors { get; set; }
        public Dbset<Book> books { get; set; }
        public Dbset<BookGroup> bookgroups { get; set; }

    }

}
