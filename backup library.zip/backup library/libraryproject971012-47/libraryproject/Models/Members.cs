﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace libraryproject.Models
{
    public class Members
    {
        [Key]
       
        public int MemberId { get; set; }
        [Display(Name = "نام کاربر")]
        [Required(ErrorMessage = "لطفا نام کاربر را وارد کنید.")]
        public string MemberName { get; set; }
        [Display(Name = "فامیلی کاربر")]
        [Required(ErrorMessage = "لطفا فامیلی کاربر را وارد کنید.")]

        public string MemberFamily { get; set; }
        [Display(Name = "نام کاربری")]
        [Required(ErrorMessage = "لطفا نام کاربری را وارد کنید.")]

        public string UserName { get; set; }
        [Display(Name = "ایمیل")]
        [Required(ErrorMessage = "لطفا ایمیل را وارد کنید.")]
        [DataType(DataType.EmailAddress,ErrorMessage ="لطفا ایمیل را به صورت صحیح وارد کنید")]
        [EmailAddress(ErrorMessage ="لطفا ایمیل را به صورت صحیح وارد کنید")]
        public string Email { get; set; }
        [Display(Name = "رمز عبور")]
        [Required(ErrorMessage = "لطفا رمزعبور را وارد کنید.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }


    }
}
