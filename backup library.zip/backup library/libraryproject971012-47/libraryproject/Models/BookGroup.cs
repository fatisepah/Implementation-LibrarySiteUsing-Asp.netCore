﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace libraryproject.Models
{
    public class BookGroup
    {
        [Key]
        public int BookGroupId { get; set; }
        public string BookGroupName { get; set; }
        public string BookGroupDescription { get; set; }
    }
}
