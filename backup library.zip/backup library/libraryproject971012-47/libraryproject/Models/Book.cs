﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace libraryproject.Models
{
    public class Book
    {
        [Key]
        public int BookId { get; set; }
        public string BookName { get; set; }
        public string BookDescription { get; set; }
        public int BookPageCount { get; set; }
        public string BookImage { get; set; }
        public int AuthorID { get; set; }
        [ForeignKey("AuthorID")]
        public virtual Author authors { get; set; }
        public int BookGroupID { get; set; }
        [ForeignKey("BookGroupID")]
        public virtual BookGroup bookgroups { get; set; }
    }
}
