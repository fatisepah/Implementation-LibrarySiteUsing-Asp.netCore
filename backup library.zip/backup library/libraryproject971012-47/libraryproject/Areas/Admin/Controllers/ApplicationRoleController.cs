﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace libraryproject.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class ApplicationRoleController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<ApplicationRole> _roleManager;
        public ApplicationRoleController(UserManager<ApplicationUser> userManagerRoleManager<ApplicationRole> roleManager)
        {
            _userManager = usermanager;
            _roleManager = roleManager;
        }
        // GET: /<controller>/
        public IActionResult Index()
        {

            List<ApplicationRoleViewModel> model = new List<ApplicationRoleViewModel>();
            model = _userManager.Roles.select(r => new ApplicationRoleViewModel
            {
                Id = r.Id,
                Name = r.Name,
                Description=r.Description,
                NumberOfUsers=r.Users.Count

            }).ToList();


            return View(model);
        }
    }
}
