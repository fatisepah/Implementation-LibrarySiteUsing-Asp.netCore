﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace libraryproject.Areas.Admin.Controllers
{
    [Area("Admin")]

    public class UserController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<ApplicationRole> _roleManager;
        public UserController(UserManager<ApplicationUser> usermanager,RoleManager<ApplicationRole> roleManager)
        {
            _userManager = usermanager;
            _roleManager = roleManager;

        }
        // GET: /<controller>/
        public IActionResult Index()
        {
            List<UserListViewModel> model = new List<UserListViewModel>();
            model = _userManager.Users.select(u => new UserListViewModel
            {
                Id = u.Id,
               Name = u.Name,
            Email = u.Email

            }).ToList();


            return View(model);
        }
    }
}
