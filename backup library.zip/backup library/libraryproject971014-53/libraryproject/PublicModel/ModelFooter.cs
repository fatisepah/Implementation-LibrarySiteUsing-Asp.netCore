﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace libraryproject.PublicModel
{
    public class ModelFooter
    {
        public string SubmitButtonText { get; set; } = "submit";
        public string CancelButtonText { get; set; } = "برگشت";
        public string SubmitButtonID { get; set; } = "btnsubmit";
        public string CancelButtonID { get; set; } = "btncancel";
        public bool OnlyCancelButton { get; set; }
    }
}
