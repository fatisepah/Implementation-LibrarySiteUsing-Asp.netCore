﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using libraryproject.Models;
using Microsoft.Extensions.DependencyInjection;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace libraryproject.Controllers
{
    public class AccountController : Controller
    {
        private IServiceProvider _serviceprovider;
        public AccountController(IServiceProvider serviceprovider)
        {
            _serviceprovider = serviceprovider;
        }

        [HttpGet]
        // GET: /<controller>/
        public IActionResult Index()
        {
            return View();
        }

        //[HttpPost]

        //public IActionResult Index(Members member)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return View(member);
        //    }
        //    using (var db = _serviceprovider.GetRequiredService<ApplicationDbContext>())
        //    {
        //        db.members.Add(member);
        //        db.SaveChanges();
        //    }
        //        return View();
        //}
    }
}
