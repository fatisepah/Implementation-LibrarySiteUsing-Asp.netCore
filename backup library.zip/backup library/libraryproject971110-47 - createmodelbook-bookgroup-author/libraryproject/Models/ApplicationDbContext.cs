﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace libraryproject.Models
{
    public class ApplicationDbContext:IdentityDbContext<ApplicationUser,ApplicationRole,string>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> option) : base(option)
        {

        }


        public DbSet<Members> members { get; set; }
        public DbSet<Author> authors { get; set; }
        public DbSet<BookGroup> bookgroups { get; set; }
        public DbSet<Book> books { get; set; }


    }
   
}
