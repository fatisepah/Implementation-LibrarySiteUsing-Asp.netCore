﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace libraryproject.Models.ViewModels
{
    public class EditUserViewModel
    {
        public int Id { get; set; }


        [Display(Name = "نام و نام خانوادگی")]
        [Required(ErrorMessage = "لطفا نام و نام خانوادگی را وارد کنید")]
        public string FullName { get; set; }


        [Display(Name = "ایمیل")]
        [Required(ErrorMessage = "لطفا ایمیل را وارد کنید")]
        public string Email { get; set; }



        public List<SelectListItem> ApplicationRoles { set; get; }
        [Display(Name = "نقش")]
        public string ApplicationRoleId { get; set; }



    }
}
