﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace libraryproject.Models.ViewModels
{
    public class BookListViewModel
    {
        public int BookId { get; set; }



        [Display(Name ="نام کتاب")]
        public string BookName { get; set; }



        [Display(Name = "تعداد صفحه کتاب")]
        public int BookPageCount { get; set; }


        public int AuthorId { get; set; }



        public int BookGroupId { get; set; }



        [Display(Name = "تصویر کتاب")]
        public string BookImage { get; set; }



        [Display(Name = "نام نویسنده کتاب")]
        public string AuthorName { get; set; }



        [Display(Name = "گروه بندی کتاب")]
        public string BookGroupName { get; set; }
    }
}
