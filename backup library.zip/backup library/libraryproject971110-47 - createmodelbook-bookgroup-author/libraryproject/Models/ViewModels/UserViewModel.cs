﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace libraryproject.Models.ViewModels
{
    public class UserViewModel
    {
        public string Id { get; set; }

        [Display(Name = "نام و نام خانوادگی")]
        [Required(ErrorMessage ="لطفا نام و نام خانوادگی را وارد کنید")]
        public string FullName { get; set; }


        [Display(Name = "ایمیل")]
        [Required(ErrorMessage = "لطفا ایمیل را وارد کنید")]
        public string Email { get; set; }


        [Display(Name = "نام کاربری")]
        [Required(ErrorMessage = "لطفا نام کاربری را وارد کنید")]
        public string UserName { get; set; }


        [Display(Name = "رمزعبور")]
        [Required(ErrorMessage = "لطفا رمزعبور را وارد کنید")]
        [DataType(DataType.Password)]
        [StringLength(20,MinimumLength =6,ErrorMessage ="حداقل طول رمزعبور 6 کاراکتر و حداکثر 20 کاراکتر باید باشد")]
        public string Password { get; set; }


        [Display(Name = "تکرار رمزعبور")]
        [Required(ErrorMessage = "لطفا تکرار رمزعبور را وارد کنید")]
        [DataType(DataType.Password)]
        public string ConfirmPass { get; set; }



        public List<SelectListItem> ApplicationRoles { set; get; }
        [Display(Name ="نقش")]
        public string ApplicationRoleId { get; set; }


    }
}
