using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using libraryproject.Models;
using libraryproject.Models.ViewModels;

namespace libraryproject.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class BookController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceProvider;
        public BookController(ApplicationDbContext context, IServiceProvider iserviceProvider)
        {
            _context = context;
            _iserviceProvider = iserviceProvider;
        }

        [HttpGet]
        public IActionResult Index()
        {
            List<BookListViewModel> model = new List<BookListViewModel>();
            //linq to querystring
            var query = (from b in _context.books
                         join a in _context.authors on b.AuthorId equals a.Id
                         join bg in _context.bookgroups on b.BookGroupId equals bg.BookGroupId


                         select new
                         {
                             b.BookId,
                             b.BookName,
                             b.BookPageCount,
                             b.BookImage,
                             b.AuthorId,
                             b.BookGroupId,
                             a.AuthorName,
                             bg.BookGroupName
                         });
            foreach(var item in query)
            {
                BookListViewModel objmodel = new BookListViewModel();
                objmodel.BookId = item.BookId;
                objmodel.BookName = item.BookName;
                objmodel.BookImage = item.BookImage;
                objmodel.BookPageCount = item.BookPageCount;
                objmodel.AuthorId = item.AuthorId;
                objmodel.BookGroupId = item.BookGroupId;
                objmodel.AuthorName = item.AuthorName;
                objmodel.BookGroupName = item.BookGroupName;
                model.Add(objmodel);
            }
            return View(model);
        }
    }
}