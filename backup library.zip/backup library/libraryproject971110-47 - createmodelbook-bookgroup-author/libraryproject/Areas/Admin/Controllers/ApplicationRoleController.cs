using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using libraryproject.Models;
using libraryproject.Models.ViewModels;

namespace libraryproject.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class ApplicationRoleController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<ApplicationRole> _roleManager;

        public ApplicationRoleController(UserManager<ApplicationUser> userManager, RoleManager<ApplicationRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }
        [HttpGet]
        public IActionResult Index()
        {
            List<ApplicationRoleListViewModel> model = new List<ApplicationRoleListViewModel>();
            model = _roleManager.Roles.Select(r => new ApplicationRoleListViewModel
            {
                Id = r.Id,
                Name = r.Name,
                Description = r.Description,
                NumberOfUsers=r.Users.Count
            }).ToList();

            return View(model);
        }
    }
}