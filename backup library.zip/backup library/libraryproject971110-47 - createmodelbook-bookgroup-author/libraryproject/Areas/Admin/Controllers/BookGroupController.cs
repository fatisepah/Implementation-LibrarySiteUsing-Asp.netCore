using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using libraryproject.Models;

namespace libraryproject.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class BookGroupController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceProvider;
        public BookGroupController(ApplicationDbContext context, IServiceProvider iserviceProvider)
        {
            _context = context;
            _iserviceProvider = iserviceProvider;
        }
        [HttpGet]
        public IActionResult Index()
        {
            List<BookGroup> model = new List<BookGroup>();
            model = _context.bookgroups.Select(bg => new BookGroup
            {
                BookGroupId = bg.BookGroupId,
                BookGroupName=bg.BookGroupName,
                BookGroupDescription=bg.BookGroupDescription
            }).ToList();
            return View(model);
        }
    }
}