using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using libraryproject.PublicModel;
using libraryproject.PublicModel.ViewModels;
using libraryproject.Models.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace libraryproject.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class UserController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<ApplicationRole> _roleManager;

        public UserController(UserManager<ApplicationUser> userManager, RoleManager<ApplicationRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }

        [HttpGet]
        public IActionResult Index()
        {
            List<UserListViewModel> model = new List<UserListViewModel>();
            model = _userManager.Users.Select(u => new UserListViewModel
            {
                id = u.Id,
                Name = u.FirstName,
                Email = u.Email
            }).ToList();

            return View(model);
        }
        [HttpGet]
        public IActionResult AddUser()
        {
            UserViewModel model = new UserViewModel();
            model.ApplicationRoles = _roleManager.Roles.Select(r => new SelectListItem
            {
                Text=r.Name,
                Value=r.Id
            }).ToList();
            return PartialView("_AddUser",model);
        }

        [HttpGet]
        public async Task<IActionResult> EditUser(string Id)
        {
            EditUserViewModel model = new EditUserViewModel();
            model.ApplicationRoles = _roleManager.Roles.Select(r => new SelectListItem
            {
                Text = r.Name,
                Value = r.Id
            }).ToList();


            if (!string.IsNullOrEmpty(Id))
            {
                ApplicationUser user = await _userManager.FindByIdAsync(Id);
                if (user != null)
                {
                    model.FullName = user.FirstName + user.LastName;
                    model.Email = user.Email;
                    model.ApplicationRoleId = _roleManager.Roles.Single(r => r.Name == _userManager.GetRolesAsync(user).Result.Single()).Id;

                }
                else
                {
                    return Redirect("Index");
                }

            }
            return PartialView("_EditUser", model);
        }
    }
}