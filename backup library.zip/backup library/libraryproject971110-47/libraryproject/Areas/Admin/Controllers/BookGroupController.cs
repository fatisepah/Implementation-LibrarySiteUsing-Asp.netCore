using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using libraryproject.PublicModel;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace libraryproject.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class BookGroupController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceProvider;
        public BookGroupController(ApplicationDbContext context, IServiceProvider iserviceProvider)
        {
            _context = context;
            _iserviceProvider = iserviceProvider;
        }
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var model = _context.bookgroups.Include(b => b.books);
            return View(await model.ToListAsync());

            //List<BookGroup> model = new List<BookGroup>();
            //model = _context.bookgroups.Select(bg => new BookGroup
            //{
            //    BookGroupId = bg.BookGroupId,
            //    BookGroupName = bg.BookGroupName,
            //    BookGroupDescription = bg.BookGroupDescription
            //}).ToList();
            //return View(model);
        }
        [HttpGet]
        public IActionResult AddEditBookGroup(int Id)
        {
            var bookgroup = new BookGroup();
            if (Id != 0)
            {
                using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
                {
                    bookgroup = _context.bookgroups.Where(bg => bg.BookGroupId == Id).SingleOrDefault();
                    if (bookgroup == null)
                    {
                        return Redirect("Index");
                    }
                }
            }
            return PartialView("_AddEditBookGroup", bookgroup);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddEditBookGroup(BookGroup model, int Id)
        {
            if (ModelState.IsValid)
            {
                if (Id == 0)
                {
                    using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
                    {
                        db.bookgroups.Add(model);
                        db.SaveChanges();

                    }
                    //return RedirectToAction("Index");
                    return PartialView("_successfullyresponse");

                }
                else
                {
                    using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
                    {
                        db.bookgroups.Update(model);
                        db.SaveChanges();
                    }
                    //return RedirectToAction("Index");
                    return PartialView("_successfullyresponse");

                }


            }
            else
            {
                return PartialView("_AddEditBookGroup", model);
            }


        }

        [HttpGet]
        public IActionResult DeleteBookGroup(int Id)
        {
            var tblbookgroup = new BookGroup();
            using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
            {
                tblbookgroup = db.bookgroups.Where(bg => bg.BookGroupId == Id).SingleOrDefault();
                if (tblbookgroup == null)
                {
                    return RedirectToAction("Index");
                }
            }
            return PartialView("_DeleteBookGroup", tblbookgroup.BookGroupName);
        }

        [HttpPost]
        public IActionResult DeleteBookGroup(int Id, string d)
        {
            using (var db = _iserviceProvider.GetRequiredService<ApplicationDbContext>())
            {
              var tblbookgroup = db.bookgroups.Where(bg => bg.BookGroupId == Id).SingleOrDefault();

                db.bookgroups.Remove(tblbookgroup);
                db.SaveChanges();
                return RedirectToAction("Index");

            }

        }

    }
}