using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using libraryproject.PublicModel;
using libraryproject.PublicModel.ViewModels;

namespace libraryproject.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class ApplicationRoleController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<ApplicationRole> _roleManager;

        public ApplicationRoleController(UserManager<ApplicationUser> userManager, RoleManager<ApplicationRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }
        [HttpGet]
        public IActionResult Index()
        {
            List<ApplicationRoleListViewModel> model = new List<ApplicationRoleListViewModel>();
            model = _roleManager.Roles.Select(r => new ApplicationRoleListViewModel
            {
                Id = r.Id,
                Name = r.Name,
                Description = r.Description,
                NumberOfUsers=r.Users.Count
            }).ToList();

            return View(model);
        }
        [HttpGet]
        public async Task<IActionResult> AddEditRole(string Id)
        {
            ApplicationRoleListViewModel model = new ApplicationRoleListViewModel();
            if (!string.IsNullOrEmpty(Id))
            {
                ApplicationRole applicationrole =await _roleManager.FindByIdAsync(Id);
                if (applicationrole != null)
                {
                    model.Id = applicationrole.Id;
                    model.Name = applicationrole.Name;
                    model.Description = applicationrole.Description;
                }
                else
                {
                    return Redirect("Index");
                }

            }




            return PartialView("_AddEditRole",model);
        }
    }
}