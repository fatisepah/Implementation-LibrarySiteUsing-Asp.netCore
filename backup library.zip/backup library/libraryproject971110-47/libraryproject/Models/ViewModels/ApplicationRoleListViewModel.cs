﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace libraryproject.PublicModel.ViewModels
{
    public class ApplicationRoleListViewModel
    {
        public string Id { get; set; }


        [Display(Name="نام نقش")]
        [Required(ErrorMessage ="لطفا عنوان نقش را وارد نمایید")]
        public string Name { get; set; }


        [Display(Name = "توضیحات نقش")]
        [Required(ErrorMessage = "لطفا توضیحات نقش را وارد نمایید")]
        public string Description { get; set; }


        public int NumberOfUsers { get; set; }
    }
}
