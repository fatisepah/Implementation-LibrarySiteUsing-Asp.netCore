﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace libraryproject.Models.ViewModel
{
    public class BookListViewModel
    {
        public int BookId { get; set; }
        public string BookName { get; set; }
        public int BookPageCount { get; set; }
        public string BookImage { get; set; }
        public int AuthorId { get; set; }
        public string AuthorName { get; set; }
        public int BookGroupId { get; set; }
        public string BookGroupName { get; set; }

    }
}
