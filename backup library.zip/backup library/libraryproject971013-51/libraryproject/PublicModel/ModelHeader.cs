﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace libraryproject.PublicModel
{
    public class ModelHeader
    {
        public string Heading { get; set; }
    }
}
