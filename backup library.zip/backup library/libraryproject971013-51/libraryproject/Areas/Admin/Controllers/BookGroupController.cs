﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using libraryproject.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace libraryproject.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class BookGroupController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceprovider;
        public BookGroupController(ApplicationDbContext context, IServiceProvider iserviceprovider)
        {
            _context = context;
            _iserviceprovider = iserviceprovider;
        }
        // GET: /<controller>/
        [HttpGet]
        public IActionResult Index()
        {
            List<BookGroup> model = new List<BookGroup>();
            model = _context.bookgroups.select(bg => new BookGroup
            {
                BookGroupId = bg.BookGroupId,
                BookGroupName=bg.BookGroupName,
                BookGroupDescription=bg.BookGroupDescription
            }).Tolist();
            return View(model);
        }
    }
}
