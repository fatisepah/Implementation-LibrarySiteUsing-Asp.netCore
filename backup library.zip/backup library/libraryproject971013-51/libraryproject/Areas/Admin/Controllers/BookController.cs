﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using libraryproject.Models;
using libraryproject.Models.ViewModel;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace libraryproject.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class BookController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceprovider;
        public BookController(ApplicationDbContext context, IServiceProvider iserviceprovide)
        {
            _context = context;
            _iserviceprovider = iserviceprovide;
        }
        // GET: /<controller>/
        [HttpGet]
        public IActionResult Index()
        {
            List<BookListViewModel> model = new List<BookListViewModel>();
            var query = (from b in _context.books
                         join a in _context.authors on b.AuthorId equals a.Id
                         join bg in _context.bookgroups on b.BookGroupId equals bg.BookGroupId
                         select new
                         {
                             b.BookId,
                             b.BookName,
                             b.BookPageCount,
                             b.BookImage,
                             a.AuthorId,
                             a.AuthorName,
                             bg.BookGroupId,
                             bg.BookGroupName
                         });
            foreach (var item in query)
            {
                BookListViewModel obj = new BookListViewModel();
                obj.BookId = item.BookId;
                obj.BookName = item.BookName;
                obj.BookPageCount = item.BookPageCount;
                obj.BookImage = item.BookImage;
                obj.AuthorId = item.AuthorId;
                obj.AuthorName = item.AuthorName;
                obj.BookGroupId = item.BookGroupId;
                obj.BookGroupName = item.BookGroupName;

                model.Add(obj);
            }
            return View(model);
        }
    }
}
