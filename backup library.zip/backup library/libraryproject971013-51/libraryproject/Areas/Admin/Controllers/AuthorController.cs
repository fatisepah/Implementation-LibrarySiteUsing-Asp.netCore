﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using libraryproject.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace libraryproject.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class AuthorController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _iserviceprovider;
        public AuthorController(ApplicationDbContext context, IServiceProvider iserviceprovider)
        {
            _context = context;
            _iserviceprovider = iserviceprovider;
        }
        // GET: /<controller>/
        [HttpGet]
        public IActionResult Index()
        {
            List<Author> model = new List<Author>();
            model = _context.authors.Select(a => new Author
            {
                Id=a.Id,
                Name=a.Name,
                Description=a.Description
            }).Tolist();
            return View(model);
        }
    }
}
